//
//  ViewController.swift
//  tapgester
//
//  Created by TOPS on 6/22/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var img1: UIImageView!
    var flag = 0 // aane tap gesture ma 2 nd 1 krai devanu nd bev mate alag alag func bnavana test and test1
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tap()        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    func tap()  {
     
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(self.test))
        let tap1 = UITapGestureRecognizer(target: self, action: #selector(self.test1))
        
        
        tap.numberOfTapsRequired = 1
        tap1.numberOfTapsRequired = 1
        img1.isUserInteractionEnabled  = true
        img.isUserInteractionEnabled = true
        img1.addGestureRecognizer(tap)
        img.addGestureRecognizer(tap1)
        
    }
    
    
    
    func test(sender:UITapGestureRecognizer)  {
        flag = 2
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
        
           }
    func test1(sender:UITapGestureRecognizer)  {
        flag = 1
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        self.present(picker, animated: true, completion: nil)
        
    }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
            if flag == 2{
                let i11 = info[UIImagePickerControllerOriginalImage]as!UIImage
                img1.image = i11;
                self.dismiss(animated: true, completion: nil)
            }
            else if flag == 1 {
                let i12 = info[UIImagePickerControllerOriginalImage]as!UIImage
            img.image = i12
                
                self.dismiss(animated: true, completion: nil)
            }
            
            
            
        }

            
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}


