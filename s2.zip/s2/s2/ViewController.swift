//
//  ViewController.swift
//  s2
//
//  Created by TOPS on 7/20/18.
//  Copyright © 2018 dp. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    var finalarr = [Any]()
        override func viewDidLoad() {
        super.viewDidLoad()
        
        getjason()
         }
    func getjason()  {
        let url = URL(string: "http://microblogging.wingnity.com/JSONParsingTutorial/jsonActors")
        do {
            let dt  = try Data(contentsOf: url!)
            
        do {
            let jasondata = try JSONSerialization.jsonObject(with: dt, options: []) as! [String:Any]
            finalarr = jasondata["actors"] as! [[String:Any]]
            print(finalarr)
            
        } catch  {
                
        }
            

        } catch  {
            
        }
        
        
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finalarr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! cust_cell
        let dic = finalarr[indexPath.row] as! [String:Any];
        cell.name.text = "name : "+(dic["name"] as? String)!;
        cell.des.text = "desc: "+(dic["description"] as? String)!;
        cell.dob.text = "dob : "+(dic["dob"] as? String)!;
        cell.country.text = "country: "+(dic["country"] as? String)!;
        cell.height.text = "height : "+(dic["height"] as? String)!;
        cell.spouse.text = "spouse : "+(dic["spouse"] as? String)!;
        cell.children.text = "children : "+(dic["children"] as? String)!;
         let imgurl = dic["image"] as? String;
        let url1 = URL(string: imgurl!)
        let request = URLRequest(url: url1!);
        cell.webv.loadRequest(request);
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 500
        
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

