//
//  cust cell.swift
//  s2
//
//  Created by TOPS on 7/20/18.
//  Copyright © 2018 dp. All rights reserved.
//

import UIKit

class cust_cell: UITableViewCell {
    
    @IBOutlet weak var webv: UIWebView!
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var des: UILabel!
  
    
    @IBOutlet weak var dob: UILabel!
    
    @IBOutlet weak var country: UILabel!
    
    
    @IBOutlet weak var height: UILabel!
    
    
    @IBOutlet weak var spouse: UILabel!
    
    @IBOutlet weak var children: UILabel!
    
    
    @IBOutlet weak var img: UILabel!
    
    
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
