//
//  custcell.swift
//  s1
//
//  Created by TOPS on 7/18/18.
//  Copyright © 2018 dp. All rights reserved.
//

import UIKit

class custcell: UITableViewCell {
    @IBOutlet weak var name: UILabel!

    @IBOutlet weak var csymbol: UILabel!
    @IBOutlet weak var ccode: UILabel!
    @IBOutlet weak var capital: UILabel!
    
    @IBOutlet weak var lname: UILabel!
    @IBOutlet weak var regian: UILabel!
    
    @IBOutlet weak var subregion: UILabel!
    
    @IBOutlet weak var area: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
