
import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var finalarr = [Any]();

    override func viewDidLoad() {
        super.viewDidLoad()
     
        jasonparse()
    }
    
    func jasonparse() {
        
        let url = URL(string: "https://restcountries.eu/rest/v2/all")
       
        do {
            let dt = try Data(contentsOf: url!)
        
        do {
            let jasondata = try JSONSerialization.jsonObject(with: dt, options: [])as![[String:Any]]
            
            finalarr = jasondata
        } catch  {
            
        }
        } catch  {
            
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return finalarr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)as! custcell;
        
        let disc = finalarr[indexPath.row] as! [String:Any]
        
        let callingCodes = disc["callingCodes"] as! [Any]
        cell.ccode.text = "calling codes : " + (String(describing: callingCodes[0]))
        
        let subregion = disc["subregion"]
        cell.subregion.text = "subregion : " + (subregion as! String?)!
        
        let region = disc["region"]
        cell.regian.text = "region : " + (region as! String?)!
        
        let capital = disc["capital"]
        cell.capital.text = "capital : " + (capital as! String?)!
        
        let name = disc["name"]
        cell.name.text = "name : " + (name as! String?)!
        
        let area = disc["area"]
        cell.area.text = "area : " + (String(describing: area!))
        
        let currencies = disc["currencies"] as! [Any]
        let symbol_disc = currencies[0] as! [String : Any]
        let symbol = symbol_disc["symbol"]
        cell.csymbol.text = "code symbol : " + (String(describing: symbol!))
        
        let languages = disc["languages"] as! [Any]
        let lrr = languages[0] as! [String:Any]
        cell.lname.text = "language name : " + (lrr["name"] as? String)!
        
        return cell
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

