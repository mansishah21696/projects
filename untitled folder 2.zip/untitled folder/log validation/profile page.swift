//
//  profile page.swift
//  log
//
//  Created by TOPS on 7/20/18.
//  Copyright © 2018 dp. All rights reserved.
//

import UIKit

class profile_page: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    var arr = ["surat1.jpg","surat1.jpg","surat1.jpg"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.leftBarButtonItem = self.editButtonItem;

           }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! custcell;
        cell.img1.image = UIImage(named: arr[indexPath.row]);
        
        return cell
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    

}
