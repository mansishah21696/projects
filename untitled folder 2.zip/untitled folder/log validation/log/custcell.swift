//
//  custcell.swift
//  log
//
//  Created by TOPS on 8/11/18.
//  Copyright © 2018 dp. All rights reserved.
//

import UIKit

class custcell: UITableViewCell {

    @IBOutlet weak var img1: UIImageView!
    
    
    @IBOutlet weak var txtview: UITextView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
