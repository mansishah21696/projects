<?php
    
    $con = new mysqli("localhost","root","","register");
    
    //$sid = $_REQUEST["sid"];
    
    $query = "select * from reg"; //where sid='$sid'";
    
    $rows = $con->query($query);
    
    while ($row = $rows->fetch_assoc()) {
        
        $pp[] = $row;
    }
    
    echo json_encode($pp);
?>
