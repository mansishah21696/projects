<?php
    
    $con = new mysqli("localhost","root","","student_db");
    
    $data = file_get_content('php://input');
    
    $dt = json_decode($data);
    
    $sname = $dt->sname;
    $sage = $dt->sage;
    
    $query = "insert into student(sname,sage)values('$sname','$sage')";
    
    $con->query($query);
    
    echo "Inserted"
?>
