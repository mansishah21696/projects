//
//  ViewController.swift
//  table2
//
//  Created by TOPS on 6/26/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate{
   var arr = ["php","java","dotnet"]
    
    var image = ["1.jpg","2.jpg","6.jpg"]
    override func viewDidLoad() {
        super.viewDidLoad()
         }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 2;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        
        //cell.accessoryType = .detailDisclosureButton;
        
        let imageview = UIImageView(frame: CGRect(x: 0, y: 0, width: 25, height: 25));
            
        imageview.image = UIImage(named: "6.jpg");
        
        cell.accessoryView = imageview;
        
        cell.imageView?.image = UIImage(named: image[indexPath.row])
        
        cell.textLabel?.text = arr[indexPath.row]
        
        return cell;
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print(arr[indexPath.row]);
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        arr.remove(at: indexPath.row);
        
        tableView.reloadData()
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "tops";
    }
    
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        return "surat";
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 25;
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 30;
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 100));
        v1.backgroundColor = UIColor.red;
        return v1;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

