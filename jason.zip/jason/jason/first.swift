//
//  first.swift
//  jason
//
//  Created by TOPS on 7/17/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class first: UIViewController,UITableViewDataSource,UITableViewDelegate{

    
    @IBOutlet weak var stname: UILabel!
    
    @IBOutlet weak var pos: UILabel!
    
    @IBOutlet weak var stdate: UILabel!
    var finalarr = [Any]()
    var trainnumber = String()
    var date = String()
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        getjason()

        // Do any additional setup after loading the view.
    }
    func getjason() {
        let url = URL(string: "https://api.railwayapi.com/v2/live/train/\(trainnumber)/date/\(date)/apikey/vtsk103fcc/")
        
        do {
            let dt = try Data(contentsOf: url!)
            
            do {
                let jasondata = try JSONSerialization.jsonObject(with: dt, options: []) as! [String : Any]
                
                print(jasondata)
                let currentstation = jasondata["current_station"]as! [String:Any]
                
                stname.text = currentstation["name"] as? String;
                stdate.text = jasondata["start_date"] as? String;
                pos.text = jasondata["position"] as? String;
                finalarr = jasondata["route"] as! [[String:Any]]
                print(finalarr)
                
                
                
            } catch  {
                
            }
        } catch  {
            
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finalarr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! cust_cell
        let dic = finalarr[indexPath.row] as! [String:Any]
        let stname = dic["station"] as! [String:Any]
        
        cell.stname.text = stname["name"] as? String;
        cell.status.text = dic["status"] as? String;
        cell.arrival.text = dic["scharr"] as? String;
        cell.dipart.text = dic["schdep"] as? String;
        
        cell.distance.text = String(dic["distance"] as! Double);
        return cell
        
        
        
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200;
    }


    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
