//
//  cust cell.swift
//  jason
//
//  Created by TOPS on 7/17/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class cust_cell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var stname: UILabel!

    @IBOutlet weak var status: UILabel!
    
    @IBOutlet weak var arrival: UILabel!
    
    @IBOutlet weak var dipart: UILabel!
    
    @IBOutlet weak var distance: UILabel!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
