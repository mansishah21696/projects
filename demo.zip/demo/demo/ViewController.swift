

import UIKit
import ImageSlideshow

class ViewController: UIViewController {

    open override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    @IBOutlet var slideshow: ImageSlideshow!
    let localSource = [ImageSource(imageString: "surat1.jpg")!, ImageSource(imageString: "img1.jpeg")!, ImageSource(imageString: "surat1.jpg")!, ImageSource(imageString: "img2.jpeg")!]
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        slideshow.slideshowInterval = 5.0
        //slideshow.pagei = .init(horizontal: .center, vertical: .under)
        slideshow.contentScaleMode = UIViewContentMode.scaleAspectFill
        
        let pageControl = UIPageControl()
        pageControl.currentPageIndicatorTintColor = UIColor.lightGray
        pageControl.pageIndicatorTintColor = UIColor.black
        //slideshow.pageIndicator = pageControl
                
        slideshow.activityIndicator = DefaultActivityIndicator()
        slideshow.currentPageChanged = { page in
            print("current page:", page)
        }
        slideshow.setImageInputs(localSource)
        
        let recognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.didTap))
        slideshow.addGestureRecognizer(recognizer)

    }
    func didTap() {
        let fullScreenController = slideshow.presentFullScreenController(from: self)
        // set the activity indicator for full screen controller (skipping the line will show no activity indicator)
        fullScreenController.slideshow.activityIndicator = DefaultActivityIndicator(style: .white, color: nil)
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }
}

