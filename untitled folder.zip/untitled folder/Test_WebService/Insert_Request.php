<?php
    
    $con = new mysqli("localhost","root","","student_db");
    
    $sname = $_REQUEST["sname"];
    $sage = $_REQUEST["sage"];
    
    $query = "insert into student(sname,sage)values('$sname','$sage')";
    
    $con->query($query);
    
    echo "Inserted"
?>
