<?php
    
    $con = new mysqli("localhost","root","","student_db");
    
    //$sid = $_REQUEST["sid"];
    
    $query = "select * from student"; //where sid='$sid'";
    
    $rows = $con->query($query);
    
    while ($row = $rows->fetch_assoc()) {
        
        $pp[] = $row;
    }
    
    echo json_encode($pp);
?>
